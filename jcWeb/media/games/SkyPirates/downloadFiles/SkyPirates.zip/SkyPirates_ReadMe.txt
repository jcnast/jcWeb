Sky Pirates

Unfortunately, we did not have time to create a solid interface for quitting the game and providing a detailed explanantion for the controls.

Therefore, please run in WINDOWED mode to more easily quit, and reference this document for the controls.

****** a CONTROLLER is needed to play this game ******

Synopsis:
	The islands hold valuable CRYSTALS that must be harvested. Unfortunately, they also keep the islands afloat. Co-operate with up to FOUR players
to fly around and destroy the islands. The SHIP can have ONE PILOT and THREE PASSENGERS while flying around. Be careful of the TURRETS that will do massive damage
to the ship and have protective SHIELDS around their guns.


CONTROLS:

No character alive:
	Y: Spawn character

As character:
	Y: Interact (consume CRYSTAL when near, get into SHIP when near, get on SHIP if someone else is piloting ship)
	A: Jump (HOLD to charge)
	RT: Shoot
	LS: Move
	RS: Aim

As Ship:
	Y: Get out/off
	RS: Move
	RT: Shoot
