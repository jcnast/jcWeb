# SisyphusEscape
Single player rogue-like game I made on my own at a game jam.

Goal: Make it to the top of the map (into the portal) and get as far as you can.

To play: Download the zip file and unzip into the same folder.


Notes:
  - Everything is randomly generated and the AI behaves randomly (although not stupidly so)
  - The game will start to lag a bit the farther you get as I ran out of time to optimize the rate at which the game
    gets more difficult (I simply add more enemies/slightly more cover rather than changing enemy speed/ reducing cover...)
